local math_sqrt = math.sqrt

local function is_point_in_front_of_camera(x, y, z)
    if not x or not y or not z then return false end
    local cx, cy, cz = getActiveCameraCoordinates()
    local lx, ly, lz = getActiveCameraPointAt()
    if not cx or not lx then return false end
    
    local dx, dy, dz = lx - cx, ly - cy, lz - cz
    local len = math_sqrt(dx * dx + dy * dy + dz * dz)
    if len < 0.001 then return false end
    local inv_len = 1 / len
    local px, py, pz = x - cx, y - cy, z - cz
    return px * dx * inv_len + py * dy * inv_len + pz * dz * inv_len > 0
end

local LAYER_COLORS = {0x60FFFFFF, 0x5080FFFF, 0x50FF80FF, 0x50FFFF80, 0x5080FF80}
local LAYER_COLOR_COUNT = #LAYER_COLORS
local RENDER_DIST_SQ = 400.0
local LINE_WIDTH = 0.8

local function renderLine3D(x1, y1, z1, x2, y2, z2, w, c)
    if not x1 or not y1 or not z1 or not x2 or not y2 or not z2 then return end
    if is_point_in_front_of_camera(x1, y1, z1) and is_point_in_front_of_camera(x2, y2, z2) then
        local px, py, pz = getCharCoordinates(PLAYER_PED)
        if px and py and pz then
            local dx, dy, dz = x1 - px, y1 - py, z1 - pz
            if (dx * dx + dy * dy + dz * dz) > RENDER_DIST_SQ then return end
        end
        local sx1, sy1 = convert3DCoordsToScreen(x1, y1, z1)
        local sx2, sy2 = convert3DCoordsToScreen(x2, y2, z2)
        if sx1 and sy1 and sx2 and sy2 then
            renderDrawLine(sx1, sy1, sx2, sy2, w, c)
        end
    end
end

local function renderMarker3D(x, y, z, color)
    if not x or not y or not z then return end
    if not is_point_in_front_of_camera(x, y, z) then return end
    local px, py, pz = getCharCoordinates(PLAYER_PED)
    if px and py and pz then
        local dx, dy, dz = x - px, y - py, z - pz
        if (dx * dx + dy * dy + dz * dz) > RENDER_DIST_SQ then return end
    end

    local sx, sy = convert3DCoordsToScreen(x, y, z)
    if sx and sy then
        local r = 4
        renderDrawLine(sx - r, sy - r, sx + r, sy - r, 1.5, color)
        renderDrawLine(sx + r, sy - r, sx + r, sy + r, 1.5, color)
        renderDrawLine(sx + r, sy + r, sx - r, sy + r, 1.5, color)
        renderDrawLine(sx - r, sy + r, sx - r, sy - r, 1.5, color)
    end
end

local PATH_LINE_COLOR    = 0xFF00FFFF
local PATH_CURRENT_COLOR = 0xFFFFFF00
local PATH_FUTURE_COLOR  = 0xFF00FF80
local PATH_LINE_WIDTH    = 2.5

local function should_render_node(node_data, x1, y1, px, py, pz, node_points_idx, node_timestamp_idx)
    if not node_data or node_data[node_timestamp_idx] == 0 then return false end
    local points = node_data[node_points_idx]
    if not points or #points == 0 or not points[1] then return false end
    if not px or not py or not pz then return false end
    local dx, dy, dz = x1 - px, y1 - py, points[1] - pz
    return dx * dx + dy * dy + dz * dz <= RENDER_DIST_SQ
end

local function render_connection(x1, y1, x2, y2, points, neighbor_points, conn)
    if not points or not neighbor_points or not conn then return end
    local z1, z2 = points[conn[1]], neighbor_points[conn[2]]
    if z1 and z2 then
        local color = LAYER_COLORS[((conn[1] - 1) % LAYER_COLOR_COUNT) + 1]
        renderLine3D(x1, y1, z1, x2, y2, z2, LINE_WIDTH, color)
    end
end

local function renderNavMesh(nav_mesh)
    if not nav_mesh or not nav_mesh.mesh then return end
    local px, py, pz = getCharCoordinates(PLAYER_PED)
    if not px or not py or not pz then return end
    local mesh = nav_mesh.mesh
    for idx, node_data in pairs(mesh) do
        local x1, y1 = nav_mesh:get_coords_from_node(idx)
        if x1 and y1 and should_render_node(node_data, x1, y1, px, py, pz, nav_mesh.NODE_POINTS, nav_mesh.NODE_TIMESTAMP) then
            local points = node_data[nav_mesh.NODE_POINTS]
            local neighbors = node_data[nav_mesh.NODE_NEIGHBORS]
            if points and neighbors then
                for neighbor_idx, connections in pairs(neighbors) do
                    local neighbor_node = mesh[neighbor_idx]
                    if neighbor_node and neighbor_node[nav_mesh.NODE_TIMESTAMP] ~= 0 then
                        local x2, y2 = nav_mesh:get_coords_from_node(neighbor_idx)
                        local neighbor_points = neighbor_node[nav_mesh.NODE_POINTS]
                        if x2 and y2 and neighbor_points and connections then
                            for i = 1, #connections do
                                render_connection(x1, y1, x2, y2, points, neighbor_points, connections[i])
                            end
                        end
                    end
                end
            end
        end
    end
end

local function renderNavPath(path, path_index)
    if not path or #path == 0 then return end
    local n   = #path
    local cur = path_index or 1
    for i = 1, n do
        local pt = path[i]
        if not pt or not pt[1] or not pt[2] or not pt[3] then break end
        local marker_color
        if i == cur then
            marker_color = PATH_CURRENT_COLOR
        else
            marker_color = PATH_FUTURE_COLOR
        end
        renderMarker3D(pt[1], pt[2], pt[3], marker_color)
        if i < n then
            local pt2 = path[i + 1]
            if pt2 and pt2[1] and pt2[2] and pt2[3] then
                renderLine3D(pt[1], pt[2], pt[3], pt2[1], pt2[2], pt2[3], PATH_LINE_WIDTH, PATH_LINE_COLOR)
            end
        end
    end
end

return {
    renderNavMesh  = renderNavMesh,
    renderNavPath  = renderNavPath,
}